/*
 1. Get Max from Start & Finish Arrays
 2. Create Temp Array of size Max(max of start, max of finish) : Space Complexity -> O(highest no. in both arrays)
 3. Traverse Start & Finish Arrays to update values of starting point & ending point of segments into temp array : Time Complexity -> O(n)
 4. Traverse Temp Array now and count the intersections by adding the elements only. Final Time Complexity = O(max_start, max_finish)
 */

import java.util.Arrays;
    
public class MaxIntersect { 
    
public static void maxIntersect(int []start,int [] finish ,int n) 
{ 
        
       	//Getting Max from Start & Finish Arrays
		int max_start = Arrays.stream(start).max().getAsInt();
		int max_finish = Arrays.stream(finish).max().getAsInt(); 
       
		//Aux Array (temp array to store which segment starts & which finishes)
		int size=max_start > max_finish ? max_start : max_finish;  
		int []arr = new int[size + 2]; //+2 is done to handle boundary cases
		Arrays.fill(arr, 0); 
           
        int cur = 0, pos = 0 ; 	//cur = current result in array iteration ; pos = position to get first X
        
        //Only those indexes in aux array will be filled which are there in start[i] & finish[i]+1 
        for(int i=0;i < n;i++) 
        {
        	arr[start[i]]++; //segment started
        	arr[finish[i] + 1]--; //segment finishing, taken +1 so as to count the ending properly
        } 
            
        int res=Integer.MIN_VALUE; 
        for(int i = 0; i <= size; i++)  
        { 
           cur += arr[i];
           if(cur > res)	//means we are getting first highest intersection at a particular time
           {
        	   res = cur;	//updating only if current is higher 
        	   pos = i;	//first position of highest intersection
           }            
        } 
      
        System.out.println("Total Intersection : " + res + " at position : " + pos); 
  
}     
       
public static void main(String[] args) {// Driver function 
       
       
        int [] start = new int[]{11, 15, 9, 5, 25, 18, 3 }; 
        int [] finish   = new int[]{47, 30, 40, 50, 35, 45, 15}; 
        int n=start.length; 
       
        maxIntersect(start,finish,n); 
    } 
} 
