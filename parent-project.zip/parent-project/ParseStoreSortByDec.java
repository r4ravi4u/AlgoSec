/*
 Step 1 : Extract meaningful data into a HashMap
 *Parse the File line by line (Split token on basis of whitespace/tabs ("" to be taken care) 
 a) Detect #Fields and check at what point "cs-host" is coming (As of now in file its Column #16)
 b) Skip Remarks Line
 c) From next Line -> Records are present finished off with a '\n'
 d) We need to go to desired Column (#16) of each record to fetch the cs-host entry
 e) Start Storing into a Hashmap : Here key is cs-host and value is occurrence of the same (Increment if encountered again)
 
 HashMap is ready now
 
 Step 2 : Sort Hashmap based on Values in Decreasing order (Used Stream API)
 a) Get Entries by entrySet method.
 b) Custom Comparator to sort by value (reverseOrder method)
 c) Put it into LinkedHashMap iterating forEachOrdered 
 */

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.*;
import java.net.*;

public class ParseStoreSortByDec {

	public static void main(String[] args) throws IOException 
	{
		/*String fPath = "C:\\Users\\ravi.gupta\\Downloads\\log_example.log";
		BufferedReader read = new BufferedReader(new FileReader(fPath));*/
		
		//Scaling it to http level
		String path = "file:\\" + System.getProperty("user.dir") + "\\log_example.log";
	   
	    URL url = new URL(path);
	    
	    BufferedReader read = new BufferedReader(new InputStreamReader(url.openStream()));

	    
		String header = "#Fields:";
		String columnHead = "cs-host";
		//String type = "http";	//used to check to discard Failed entries	
	    
	    
	    String line;
	    
	    Pattern regex = Pattern.compile("[^\\s\"]+|\"[^\"]*\"");	//Regex pattern for spaces & double quotes
	    int pos = 0;
	    boolean flag = true;
	    
	    HashMap<String, Integer> map = new HashMap<>();
	 
	    while ((line = read.readLine()) != null)
	    {
	    	if(!(line.contains(header)) && pos == 0)	//First to check till header part comes up 
	    		continue;
	    	
	    	if(!flag)	//If header found, Skip the next Remarks line
	    	{
	    		flag = true;
	    		continue;
	    	}
	    	
	    	List<String> str = new ArrayList<>();
	    	Matcher match = regex.matcher(line);
	    	
	    	while (match.find()) {	//making tokens & add to str
	    	    str.add(match.group());
	    	} 
	    
	    	//str = line.trim().split("?:(['\"])(.*?)(?<!\\)(?>\\\\)*\1|([^\\s]+)"); 
	    	
	    	//System.out.println(Arrays.toString(str));
	    	 
	    	 if(pos == 0)	//only for header part 
	    	 {
	    		 for(String s : str)
	    		 {
		    		 if(s.equals(columnHead))	//as soon as we get cs-host in this case
		    			 break;
		    		 
		    		 pos++;
		    	 }
	    		 
	    		 flag = false;
	    	 }
	    	 //System.out.println(pos);
	    	 
	    	 else
	    	 {
	    		 /*if(!(str.get(pos-2).equals(type)))	//to discard Failed entries
	    			 continue;*/
	    		 
	    		 String key = str.get(pos-1);
	    		 int count = map.containsKey(key) ? map.get(key) : 0;
	    		 map.put(key, count + 1);
		    	 
		    	// System.out.println(str[pos-1]);
	    		 
	    		  
	    	 }
	    	 
	    }
	    
	    read.close();	//else it will be a resoure leak
	    
	    //Till Here our Hashmap (map) is generated : Step 1 Completed
	    
	    //Step 2 Starts now 
	    
	    LinkedHashMap<String, Integer> lhm = new LinkedHashMap<>();	//maintains insertion order
	    
	    //Using Stream API to Sort in Reverse order and insert into LHM.
	    map.entrySet().stream().sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
        .forEachOrdered(item -> lhm.put(item.getKey(), item.getValue()));
 
	    //Final Print as Desired
	    for(String key : lhm.keySet())
	    	System.out.println("Host: " + key.toString() + ", Count: " + lhm.get(key).toString());

	}
}
